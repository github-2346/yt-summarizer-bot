from dotenv import load_dotenv
load_dotenv()

from telegram.ext import ApplicationBuilder, MessageHandler, filters
from handlers import handle_message
import os

app = ApplicationBuilder().token(
    os.getenv("TELEGRAM_BOT_TOKEN")
).build()

app.add_handler(MessageHandler(filters.TEXT, handle_message))

app.run_polling()