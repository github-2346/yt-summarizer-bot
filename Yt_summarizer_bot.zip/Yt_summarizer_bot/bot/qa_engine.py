from openai import OpenAI
import os

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL")
)

MODEL = "llama-3.1-8b-instant"


def answer_question(transcript, question, language="English"):
    prompt = f"""
Answer ONLY using transcript context.

If not found reply exactly:
This topic is not covered in the video.

Language: {language}

Transcript:
{transcript[:10000]}

Question:
{question}
"""

    response = client.chat.completions.create(
        model=MODEL,
        messages=[{"role":"user","content":prompt}
    ])

    return response.choices[0].message.content