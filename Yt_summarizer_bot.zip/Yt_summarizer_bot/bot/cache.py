import json
import os

CACHE_FILE = "data/transcripts_cache.json"

def load_cache():
    if not os.path.exists(CACHE_FILE):
        return {}
    with open(CACHE_FILE, "r") as f:
        return json.load(f)

def save_cache(data):
    with open(CACHE_FILE, "w") as f:
        json.dump(data, f)

def get_cached(video_id):
    return load_cache().get(video_id)

def save_cached(video_id, transcript):
    data = load_cache()
    data[video_id] = transcript
    save_cache(data)