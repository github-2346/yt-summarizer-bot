from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api.formatters import TextFormatter
import re


def extract_video_id(url):
    patterns = [
        r"v=([a-zA-Z0-9_-]+)",
        r"youtu\.be/([a-zA-Z0-9_-]+)"
    ]

    for p in patterns:
        match = re.search(p, url)
        if match:
            return match.group(1)
    return None


def get_transcript(url):
    video_id = extract_video_id(url)

    if not video_id:
        return None, "Invalid YouTube URL"

    try:
        api = YouTubeTranscriptApi()

        # NEW SYNTAX (v1.x)
        transcript_list = api.list(video_id)

        transcript = None

        # try English first
        try:
            transcript = transcript_list.find_transcript(["en"])
        except:
            transcript = next(iter(transcript_list))

        data = transcript.fetch()

        formatter = TextFormatter()
        text = formatter.format_transcript(data)

        return text, None

    except Exception as e:
        print("REAL TRANSCRIPT ERROR:", e)
        return None, "Transcript not available"