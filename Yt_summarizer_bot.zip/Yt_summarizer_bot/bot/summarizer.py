from openai import OpenAI
import os

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL")
)

MODEL = "llama-3.1-8b-instant"


def ask_ai(prompt):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content


def summarize(text, language="English"):
    prompt = f"""
Summarize this YouTube transcript in {language}.

Format:
🎥 Video Summary
📌 5 Key Points
⏱ Important Timestamps
🧠 Core Takeaway

Transcript:
{text[:8000]}
"""
    return ask_ai(prompt)


def deep_dive(text, language="English"):
    prompt = f"""
Explain this video deeply in {language}.
Make it easy to understand with clear sections.

Transcript:
{text[:8000]}
"""
    return ask_ai(prompt)


def action_points(text, language="English"):
    prompt = f"""
Extract practical action points from this video in {language}.
Use bullet points.

Transcript:
{text[:8000]}
"""
    return ask_ai(prompt)