from transcript import get_transcript
from summarizer import summarize, deep_dive, action_points
from qa_engine import answer_question

# session memory (per user)
sessions = {}


async def handle_message(update, context):
    msg = (update.message.text or "").strip()
    user_id = update.message.chat_id

    # Ensure user session exists and preserve language across videos
    if user_id not in sessions:
        sessions[user_id] = {"language": "English"}

    # START COMMAND 
    if msg == "/start":
        await update.message.reply_text(
            "👋 Welcome!\n\n"
            "Send a YouTube link to get:\n"
            "🎥 Summary\n📌 Key points\n🧠 Q&A\n\n"
            "Commands:\n"
            "/summary\n"
            "/deepdive\n"
            "/actionpoints\n"
            "/lang Hindi (or English)"
        )
        return

    # LANGUAGE COMMAND
    if msg.startswith("/lang"):
        lang = msg.replace("/lang", "", 1).strip().capitalize() or "English"
        sessions[user_id]["language"] = lang
        await update.message.reply_text(f"Language set to {lang}")
        return

    #  YOUTUBE LINK 
    if "youtube.com" in msg or "youtu.be" in msg:
        transcript, err = get_transcript(msg)

        if err:
            await update.message.reply_text(err)
            return

        # Preserve previously selected language
        lang = sessions[user_id].get("language", "English")
        sessions[user_id]["transcript"] = transcript

        summary = summarize(transcript, lang)
        await update.message.reply_text(summary)
        return

    # CHECK SESSION 
    if "transcript" not in sessions[user_id]:
        await update.message.reply_text("Send YouTube link first.")
        return

    transcript = sessions[user_id]["transcript"]
    lang = sessions[user_id].get("language", "English")

    #  COMMANDS 
    if msg == "/summary":
        result = summarize(transcript, lang)
    elif msg == "/deepdive":
        result = deep_dive(transcript, lang)
    elif msg == "/actionpoints":
        result = action_points(transcript, lang)
    elif msg.startswith("/"):
        # Unknown command guard
        await update.message.reply_text("Unknown command. Use /start to see available commands.")
        return
    else:
        # Normal Q&A
        result = answer_question(transcript, msg, lang)

    await update.message.reply_text(result)