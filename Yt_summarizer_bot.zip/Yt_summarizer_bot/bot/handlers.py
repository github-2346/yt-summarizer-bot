from transcript import get_transcript
from summarizer import summarize, deep_dive, action_points
from qa_engine import answer_question

# session memory
sessions = {}


async def handle_message(update, context):
    msg = update.message.text.strip()
    user_id = update.message.chat_id

    # LANGUAGE COMMAND
    if msg.startswith("/lang"):
        lang = msg.replace("/lang", "").strip().capitalize()

        if user_id not in sessions:
            sessions[user_id] = {}

        sessions[user_id]["language"] = lang or "English"

        await update.message.reply_text(f"Language set to {lang}")
        return

    # YOUTUBE LINK 
    if "youtube.com" in msg or "youtu.be" in msg:
        transcript, err = get_transcript(msg)

        if err:
            await update.message.reply_text(err)
            return

        sessions[user_id] = {
            "transcript": transcript,
            "language": "English"
        }

        summary = summarize(transcript, "English")
        await update.message.reply_text(summary)
        return

    #  CHECK SESSION 
    if user_id not in sessions or "transcript" not in sessions[user_id]:
        await update.message.reply_text("Send YouTube link first.")
        return

    transcript = sessions[user_id]["transcript"]
    lang = sessions[user_id]["language"]

    # START COMMAND 
    if msg == "/start":
        await update.message.reply_text(
            "Welcome!\n\nSend a YouTube link to get:\n"
            "🎥 Summary\n📌 Key points\n🧠 Q&A\n\n"
            "Commands:\n"
            "/summary\n/deepdive\n/actionpoints\n/lang Hindi"
        )
        return
    #  COMMANDS 
    if msg == "/summary":
        result = summarize(transcript, lang)

    elif msg == "/deepdive":
        result = deep_dive(transcript, lang)

    elif msg == "/actionpoints":
        result = action_points(transcript, lang)

    else:
        # normal Q&A
        result = answer_question(transcript, msg, lang)

    await update.message.reply_text(result)