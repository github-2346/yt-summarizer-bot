from deep_translator import GoogleTranslator

def translate(text, target_lang):
    try:
        return GoogleTranslator(source="auto",
                                target=target_lang).translate(text)
    except:
        return text